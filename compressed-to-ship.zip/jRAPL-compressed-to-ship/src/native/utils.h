#ifndef UTILS_H
#define UTILS_H

int sleep_millisecond(long msec);

#endif //UTILS_H
